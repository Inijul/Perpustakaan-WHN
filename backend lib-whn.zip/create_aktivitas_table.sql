-- SQL untuk membuat tabel aktivitas sesuai dengan struktur database yang diberikan
CREATE TABLE aktivitas (
    id_aktivitas VARCHAR(50) PRIMARY KEY NOT NULL,
    kode VARCHAR(50) NOT NULL,
    nrm VARCHAR(12) NOT NULL,
    status ENUM('dipinjam', 'dikembalikan') NOT NULL,
    tanggal_peminjaman DATE NOT NULL,
    jatuh_tempo DATE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (kode) REFERENCES koleksi(kode) ON DELETE CASCADE,
    FOREIGN KEY (nrm) REFERENCES mahasiswa(nrm) ON DELETE CASCADE
);

-- Index untuk optimasi query
CREATE INDEX idx_aktivitas_kode ON aktivitas(kode);
CREATE INDEX idx_aktivitas_nrm ON aktivitas(nrm);
CREATE INDEX idx_aktivitas_status ON aktivitas(status);
CREATE INDEX idx_aktivitas_tanggal ON aktivitas(tanggal_peminjaman);
