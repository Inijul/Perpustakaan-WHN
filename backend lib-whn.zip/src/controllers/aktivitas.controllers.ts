import { Request, Response } from "express";
import db from "../config/database";

// GET semua aktivitas
export const getAktivitas = async (req: Request, res: Response) => {
  try {
    const [rows] = await db.query(`
      SELECT a.id_aktivitas, a.kode, a.nrm, a.status, a.tanggal_peminjaman, a.jatuh_tempo,
             m.nama AS nama_mahasiswa, k.judul AS judul_buku
      FROM aktivitas a
      JOIN mahasiswa m ON a.nrm = m.nrm
      JOIN koleksi k ON a.kode = k.kode
      ORDER BY a.tanggal_peminjaman DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Error mengambil data aktivitas", error: err });
  }
};

// GET aktivitas berdasarkan ID
export const getAktivitasById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const [rows] = await db.query(
      `
      SELECT a.id_aktivitas, a.kode, a.nrm, a.status, a.tanggal_peminjaman, a.jatuh_tempo,
             m.nama AS nama_mahasiswa, k.judul AS judul_buku
      FROM aktivitas a
      JOIN mahasiswa m ON a.nrm = m.nrm
      JOIN koleksi k ON a.kode = k.kode
      WHERE a.id_aktivitas = ?
      `,
      [id]
    );

    if ((rows as any[]).length === 0) {
      return res.status(404).json({ message: "Aktivitas tidak ditemukan" });
    }

    res.json((rows as any[])[0]);
  } catch (err) {
    res.status(500).json({ message: "Error mengambil aktivitas", error: err });
  }
};

// CREATE aktivitas (peminjaman)
export const createAktivitas = async (req: Request, res: Response) => {
  try {
    const { id_aktivitas, kode, nrm, status, tanggal_peminjaman, jatuh_tempo } = req.body;

    // Validasi status enum
    if (!['dipinjam', 'dikembalikan'].includes(status)) {
      return res.status(400).json({ message: "Status harus 'dipinjam' atau 'dikembalikan'" });
    }

    await db.query(
      "INSERT INTO aktivitas (id_aktivitas, kode, nrm, status, tanggal_peminjaman, jatuh_tempo) VALUES (?, ?, ?, ?, ?, ?)",
      [id_aktivitas, kode, nrm, status, tanggal_peminjaman, jatuh_tempo]
    );

    res.status(201).json({ message: "Aktivitas berhasil ditambahkan" });
  } catch (err) {
    res.status(500).json({ message: "Error menambah aktivitas", error: err });
  }
};

// UPDATE aktivitas (misalnya update status kembali)
export const updateAktivitas = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { status, jatuh_tempo } = req.body;

    // Validasi status enum
    if (status && !['dipinjam', 'dikembalikan'].includes(status)) {
      return res.status(400).json({ message: "Status harus 'dipinjam' atau 'dikembalikan'" });
    }

    const updateFields = [];
    const updateValues = [];

    if (status) {
      updateFields.push("status = ?");
      updateValues.push(status);
    }

    if (jatuh_tempo) {
      updateFields.push("jatuh_tempo = ?");
      updateValues.push(jatuh_tempo);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({ message: "Tidak ada field yang diupdate" });
    }

    updateValues.push(id);

    await db.query(
      `UPDATE aktivitas SET ${updateFields.join(", ")} WHERE id_aktivitas = ?`,
      updateValues
    );

    res.json({ message: "Aktivitas berhasil diperbarui" });
  } catch (err) {
    res.status(500).json({ message: "Error update aktivitas", error: err });
  }
};

// DELETE aktivitas (jika perlu)
export const deleteAktivitas = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    await db.query("DELETE FROM aktivitas WHERE id_aktivitas = ?", [id]);
    res.json({ message: "Aktivitas berhasil dihapus" });
  } catch (err) {
    res.status(500).json({ message: "Error hapus aktivitas", error: err });
  }
};