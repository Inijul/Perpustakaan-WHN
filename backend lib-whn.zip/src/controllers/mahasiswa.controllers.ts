import { Request, Response } from "express";
import db from "../config/database";

// GET semua mahasiswa
export const getMahasiswa = async (req: Request, res: Response) => {
  try {
    const [rows] = await db.query(`
      SELECT nrm, nama, jurusan, angkatan
      FROM mahasiswa
      ORDER BY nama
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Error mengambil data mahasiswa", error: err });
  }
};

// GET mahasiswa berdasarkan NRM
export const getMahasiswaByNrm = async (req: Request, res: Response) => {
  try {
    const { nrm } = req.params;
    const [rows] = await db.query(
      `SELECT nrm, nama, jurusan, angkatan FROM mahasiswa WHERE nrm = ?`,
      [nrm]
    );

    if ((rows as any[]).length === 0) {
      return res.status(404).json({ message: "Mahasiswa tidak ditemukan" });
    }

    res.json((rows as any[])[0]);
  } catch (err) {
    res.status(500).json({ message: "Error mengambil mahasiswa", error: err });
  }
};

// CREATE mahasiswa
export const createMahasiswa = async (req: Request, res: Response) => {
  try {
    const { nrm, nama, jurusan, angkatan } = req.body;

    await db.query(
      "INSERT INTO mahasiswa (nrm, nama, jurusan, angkatan) VALUES (?, ?, ?, ?)",
      [nrm, nama, jurusan, angkatan]
    );

    res.status(201).json({ message: "Mahasiswa berhasil ditambahkan" });
  } catch (err) {
    res.status(500).json({ message: "Error menambah mahasiswa", error: err });
  }
};
