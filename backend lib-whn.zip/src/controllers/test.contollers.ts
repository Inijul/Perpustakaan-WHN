import { Request, Response } from "express";
import db from "../config/database"; // sesuaikan path config db kamu

export const testDbConnection = async (req: Request, res: Response) => {
  try {
    const [rows] = await db.query("SHOW TABLES");
    res.status(200).json({
      message: "Database connected ✅",
      tables: rows,
    });
  } catch (error) {
    res.status(500).json({
      message: "Database connection failed ❌",
      error,
    });
  }
};
